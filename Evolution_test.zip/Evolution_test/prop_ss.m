function uout = prop_ss(uin,linop1,nlop1,h)
uf1 = fft(nlop1(h/2,uin));
ut1 = ifft(linop1(h,uf1));
uout = nlop1(h/2,ut1);
end