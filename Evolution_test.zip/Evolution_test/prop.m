function uout = prop(uin,linop1,nlop1,T,theta)
err_lower = 1e-9;
err_upper = 1e-7;

t_next = 0;
h = 1e-5;
utc = uin;
putc = utc;
counter = 0;

while t_next < T
ut0 = prop_ss(utc,linop1,nlop1,h);
ut1 = prop_ss(utc,linop1,nlop1,h/2);
ut2 = prop_ss(ut1,linop1,nlop1,h/2);


steperr = norm(abs(ut2)-abs(ut0))/norm(abs(ut0));

if steperr<err_upper
    
    
    utc = (4*ut2-ut0)/3;
    %utc = ut2;
    t_next = t_next + h;
    conv_err = norm(abs(putc)-abs(utc))/norm(abs(putc));
    counter = counter + 1;
    
%     if rem(counter,100) == 0
%         plot(theta,abs(utc));
%         ylim([0 5])
%         drawnow()
%        fprintf("Convergence Error: %e ---- t = %f ---- Step-Size: %e ---- Step-Err: %e\n",conv_err,t_next,h,steperr); 
%     end
    
    putc = utc;
   if steperr<err_lower
      h = h*1.7;
   end
    
else
   h = h*2/3;
   if h<1e-20
      error("Step-size not converging..."); 
   end
end

end

uout = utc;

end