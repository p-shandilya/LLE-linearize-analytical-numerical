function uout = lin2dbm(uin,flag)
uf = fftshift(abs(fft(uin.^1)));
if flag == 1
    uf = uf./max(uf);
elseif flag == 2
    uf = uf./1e-3;
else
    error("flag can be 1 or 2");
end

uout = 10*log10(uf);

end