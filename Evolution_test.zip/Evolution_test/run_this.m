%Author: Pradyoth Shandilya - shandilya@umbc.edu
%Last updated: 08-08-22

close all
clearvars
clc

N = 2^10; 
naxis = (-N/2:N/2-1).';
dth = 2*pi/N;
theta = naxis*dth; 

dw = 1; 
w = fftshift(dw*naxis); %"Mode number" axis

beta2 = -0.1549;
beta3 = -beta2/10; %Change last digit to 4
beta4 = 0*beta3/100; %Change last digit to 1
beta5 = +0.00000000;
F = 2.5655; 
l = 2 + 2i*4.3; % "Imaginary part is the detuning term" %Detuning of 3.579 generates single soliton
%load u_ans.mat
%uin = u_ans;
Dm = ((1/2)*beta2*(w).^2 + (1/6)*beta3*(w).^3 + (1/24)*beta4*w.^4 + (1/120)*beta5*w.^5);

gam1 = 1;
Ff = fft(F*ones(N,1)); 

linop1 = @(h,uf1) exp(h*(1i*Dm - l/2)).*(uf1 + Ff./(1i*Dm - l/2)) - Ff./(1i*Dm - l/2);
nlop1 = @(h,ut1) exp(1i*h*gam1*abs(ut1).^2).*ut1;
figure(100);


yyaxis right
subplot(2,2,1)
plot(ifftshift(w),ifftshift(Dm))
yline(0)
drawnow()
T = 1000; %Max run "distance" 

uin = 3*sech(5*theta); %Input initial condition
%uin = 1e-3*abs(rand(size(theta)));
%uin = F*ones(N,1) + 1e-3*abs(rand(size(theta)));

store_RT = []; %Store intracavity pulse every round-trip
xlabel('\theta')
ylabel('|\Psi|^2')
uout = uin;
energy_arr = [];
amplitude_arr = [];
for counter = 1:T
uout = prop(uout,linop1,nlop1,1,theta);
subplot(2,2,2)
plot(theta,abs(uout).^2);
title(counter)
drawnow()
energy_arr = [energy_arr;norm(uout)];
amplitude_arr = [amplitude_arr;max(abs(uout))];
if rem(counter,20)==0
    subplot(2,2,3)
plot(energy_arr)
title(counter)
subplot(2,2,4)
plot(amplitude_arr)
title(counter)
drawnow()
end
store_RT = [store_RT,abs(uout).^2];
end



uf = fft(uout);
%uf = lin2dbm(uout,1);
yyaxis left
u_int_fft = abs(fftshift(uf)).^2;
u_norm = u_int_fft / max(u_int_fft);
u_db = 10*log10(u_norm);
figure
u_sm = stem(fftshift(w),u_db,'Marker','None','Color','b','LineWidth',2);
u_sm.BaseValue = -400;
%xlim([-40,40]);
%ylim([-70,0]);
xlabel("Relative mode number")
ylabel("Power (dB)")

figure
imagesc((1:T),linspace(-pi,pi,N),store_RT)
xlabel('Round-Trips')
ylabel('\theta')
ylabel('\theta','FontSize',16)
title('Pulse propagation inside the microresonator with HOD')

